import { Pipe, PipeTransform } from '@angular/core';
import { Book} from './book';
@Pipe({
  name: 'bookAuthorFilter'
})
export class BookAuthorFilterPipe implements PipeTransform {
  
  str:string;
  transform(books: Book[], args: string[]): Book[] {
    // let filter:string = args[0] ? args[0].toString().toLocaleLowerCase() : null ;
    //     return filter? value.filter((book:Book)=> book.title.toLocaleLowerCase().indexOf(filter) != -1) : value;

    if(!books) return [];
    if(!args) return books;
    this.str = args.toString().toLocaleLowerCase();
      return books.filter( book => 
       book.author.toString().toLocaleLowerCase().includes(this.str)
    );
  }

}
