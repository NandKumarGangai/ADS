import { BookAuthorFilterPipe } from './book-author-filter.pipe';

describe('BookAuthorFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new BookAuthorFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
