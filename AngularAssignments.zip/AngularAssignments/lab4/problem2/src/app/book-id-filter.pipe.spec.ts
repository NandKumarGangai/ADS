import { BookIdFilterPipe } from './book-id-filter.pipe';

describe('BookIdFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new BookIdFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
