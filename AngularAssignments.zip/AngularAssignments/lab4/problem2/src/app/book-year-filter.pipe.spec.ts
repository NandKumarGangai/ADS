import { BookYearFilterPipe } from './book-year-filter.pipe';

describe('BookYearFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new BookYearFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
