import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
@Component({
  selector: 'app-add-movie',
  templateUrl: './add-movie.component.html',
  styleUrls: ['./add-movie.component.css']
})
export class AddMovieComponent implements OnInit {
  mCategories:string[] = ['drama', 'fiction' ,'satire'];

  // movieForm = this.fb.group({
  //     name : ['', Validators.required],
  //     rating: ['', Validators.required, Validators.min(0), Validators.max(5)],
  //     category: ['', Validators.required]
  // });
  movieForm : FormGroup;
  name : FormControl;
  rating: FormControl;
  category: FormControl;
  
  
  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.movieForm = new FormGroup({
      name : this.name = new FormControl('', Validators.required),
      rating : this.rating = new FormControl('', [Validators.required, Validators.min(0), Validators.max(5)]),
      category : this.category = new FormControl('', Validators.required), 
    });
  }

  onSubmit(){
    console.log(this.movieForm.value );
  }

}
