export class Product {
    productId:number;
    productName:string;
    productCost:number;
    productOnline:boolean;
    productCategory:any;
    availStores:any[];
}
