import { Component, OnInit } from '@angular/core';
import {Product} from '../product';
import {NgForm} from '@angular/forms';
@Component({
  selector: 'app-products-form',
  templateUrl: './products-form.component.html',
  styleUrls: ['./products-form.component.css']
})
export class ProductsFormComponent implements OnInit {
  submitted = false;
  product = new Product();
  flagBlur:boolean=false;
  stores = [{name: 'D Mart', checked:false}, {name: 'Big Bazar', checked:false}, {name: 'Mega Store', checked:false}, {name: 'Reliance', checked:false}];
  constructor() { }

  ngOnInit() {
  }
  validate(){
    this.flagBlur=true;
  }

  validateCheckbox():boolean{ 
    for(let s of this.stores){
      if(s.checked == true){
        return true;
      }
    }
    return false;
  }

  onSubmit(f:NgForm) { this.submitted = true;
    console.log("Product Id: "+this.product.productId);
    console.log("Product Name: "+this.product.productName);
    console.log("Product Cost: "+this.product.productCost);
    console.log("Product availability: "+this.product.productOnline);
    console.log("Product Category: "+this.product.productCategory);
    for(let store of this.stores){
      if(store.checked==true) {
        console.log("Available in stores: "+store.name);      }
    }
  }
  
  storeClicked(s){

    for(let i=0; i< this.stores.length; i++){
      
      if(this.stores[i].name == s.name){
        this.stores[i].checked=!this.stores[i].checked;
       console.log(s);
      }
    }
  } 

}
