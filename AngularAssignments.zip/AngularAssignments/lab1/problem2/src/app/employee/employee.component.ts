import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  empId:string;
  empName:string;
  empSalary:number;
  empDept:string;
  constructor() { }

  ngOnInit() {
  }

  showEmpDetail(){
    alert(this.empId+" "+this.empName+" "+this.empSalary+" "+this.empDept);
  }

}
