import {SmartPhone} from './smartPhone';
import {BasicPhone} from './basicPhone';

class BasicPhoneDetails extends BasicPhone{

}

class SmartPhoneDetails extends SmartPhone{

}

let BPD = new BasicPhoneDetails("Basic Phone", 1200, "NOKIA", 12300);
console.log(BPD.printMobileDetails());

let SPD = new SmartPhoneDetails("Smart Phone", 1400, "MOTO", 16300);
console.log(SPD.printMobileDetails());