"use strict";
exports.__esModule = true;
var Mobile = /** @class */ (function () {
    function Mobile(mobileId, mobileName, mobileCost) {
        this.mobileId = mobileId;
        this.mobileName = mobileName;
        this.mobileCost = mobileCost;
    }
    Mobile.prototype.printMobileDetails = function () {
        console.log("Mobile ID is: " + this.mobileId);
        console.log("Mobile Name is: " + this.mobileName);
        console.log("Mobile Cost is: " + this.mobileCost);
    };
    return Mobile;
}());
exports.Mobile = Mobile;
