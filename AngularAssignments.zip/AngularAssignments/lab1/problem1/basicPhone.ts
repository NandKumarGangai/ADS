import {Mobile} from './mobile';

export class BasicPhone extends Mobile{
    mobileType:string;
    constructor(mobileType:string, mobileId, mobileName, mobileCost){
        super(mobileId, mobileName, mobileCost);
        this.mobileType = mobileType;
    }
    printMobileDetails(){
        super.printMobileDetails();
        console.log("Mobile Type is: "+this.mobileType);
    }
}
