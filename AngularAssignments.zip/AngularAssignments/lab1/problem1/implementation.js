"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
var smartPhone_1 = require("./smartPhone");
var basicPhone_1 = require("./basicPhone");
var BasicPhoneDetails = /** @class */ (function (_super) {
    __extends(BasicPhoneDetails, _super);
    function BasicPhoneDetails() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return BasicPhoneDetails;
}(basicPhone_1.BasicPhone));
var SmartPhoneDetails = /** @class */ (function (_super) {
    __extends(SmartPhoneDetails, _super);
    function SmartPhoneDetails() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return SmartPhoneDetails;
}(smartPhone_1.SmartPhone));
var BPD = new BasicPhoneDetails("Basic Phone", 1200, "NOKIA", 12300);
console.log(BPD.printMobileDetails());
var SPD = new SmartPhoneDetails("Smart Phone", 1400, "MOTO", 16300);
console.log(SPD.printMobileDetails());
