export class Mobile {
    mobileId:number;
    mobileName:string;
    mobileCost:number;
    constructor(mobileId:number, mobileName:string, mobileCost:number){
        this.mobileId = mobileId;
        this.mobileName = mobileName;
        this.mobileCost = mobileCost;
    }
    printMobileDetails(){
        console.log("Mobile ID is: "+this.mobileId);
        console.log("Mobile Name is: "+this.mobileName);
        console.log("Mobile Cost is: "+this.mobileCost);
    }
}