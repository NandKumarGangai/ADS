import { Component, OnInit } from '@angular/core';
import {IEmployee} from './employee';
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
    update:boolean=false;
    flag:boolean=false;
    selectedEmpId:number;
    empId:number;
    empName:string;
    empSalary:number;
    empDept:string;

    UempId:number;
    UempName:string;
    UempSalary:number;
    UempDept:string;

  empList:IEmployee[] = [{"empId":1001,"empName":"Rahul","empSalary":9000,"empDept":"Java"},
  {"empId":1002,"empName":"Sachin","empSalary":19000,"empDept":"OraApps"},
  {"empId":1003,"empName":"Vikash","empSalary":29000,"empDept":"BI"}
];
  constructor() { }

  ngOnInit() {
  }

  deleteRow(id):void{
    for(let i = 0; i < this.empList.length; ++i){
        if (this.empList[i].empId === id) {
            this.empList.splice(i,1);
        }
    }
  }
  addEmployee():void{
    let emp = JSON.parse(`{"empId":${this.empId},"empName":"${this.empName}","empSalary":${this.empSalary},"empDept":"${this.empDept}"}`);
    this.empList.push(emp);
    console.log(this.empList);
  }

  updateStatus(id){
    this.selectedEmpId = id;
    this.update=!this.update;
  }

  updateEmployee():void{
    this.flag = false;
    for(let emp of this.empList){
      if(emp.empId == this.selectedEmpId){
        if(this.UempName != undefined){emp.empName = this.UempName};
        if(this.UempSalary != undefined){emp.empSalary = this.UempSalary};
        if(this.UempDept != undefined){emp.empDept = this.UempDept};
        console.log(emp);
        this.flag = true;
        this.UempId=0;
        this.UempName="";
        this.UempSalary=0;
        this.UempDept="";
        alert("Employee data updated successfully...!");
      }      
    }
    if(!this.flag){ alert("Invalid Employee Number");}
  }

}
