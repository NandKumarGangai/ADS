import { Component, OnInit } from '@angular/core';
import {Employee} from './employee';
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  empList:Employee[] = [
      {empId:1001,empName:'Rahul',empSal:9000,empDep:'JAVA',empjoiningdate:'6/12/2014'},
      {empId:1002,empName:'Vikash',empSal:11000,empDep:'ORAAPS',empjoiningdate:'6/12/2017'},
      {empId:1003,empName:'Uma',empSal:12000,empDep:'JAVA',empjoiningdate:'6/12/2010'},
      {empId:1004,empName:'Sachin',empSal:11500,empDep:'ORAAPS',empjoiningdate:'11/12/2017'},
      {empId:1005,empName:'Amol',empSal:7000,empDep:'.NET',empjoiningdate:'1/1/2018'},
      {empId:1006,empName:'Vishal',empSal:17000,empDep:'BI',empjoiningdate:'9/12/2012'},
      {empId:1007,empName:'Rajita',empSal:21000,empDep:'BI',empjoiningdate:'6/7/2014'},
      {empId:1008,empName:'Neelima',empSal:81000,empDep:'TESTING',empjoiningdate:'6/17/2015'},
      {empId:1009,empName:'Daya',empSal:1000,empDep:'TESTING',empjoiningdate:'6/17/2016'}
];
  emp:Employee;
  records: Array<any>;
  isDesc: boolean = false;
  column: string = 'empId';
  constructor() { }

  ngOnInit() {
  }
  sort(s):void{
    if(s == "id"){
      for(let i =0; i<this.empList.length-1; i++){
        for(let j=i; j<this.empList.length; j++){
          if(this.empList[i].empId > this.empList[j].empId){
            this.emp = this.empList[i];
            this.empList[i] = this.empList[j];
            this.empList[j] = this.emp;
          }
        }
      }
    }

    if(s == "name"){
      for(let i =0; i<this.empList.length-1; i++){
        for(let j=i; j<this.empList.length; j++){
          if(this.empList[i].empName > this.empList[j].empName){
            this.emp = this.empList[i];
            this.empList[i] = this.empList[j];
            this.empList[j] = this.emp;
          }
        }
      }
    }

    if(s == "sal"){
      for(let i =0; i<this.empList.length-1; i++){
        for(let j=i; j<this.empList.length; j++){
          if(this.empList[i].empSal > this.empList[j].empSal){
            this.emp = this.empList[i];
            this.empList[i] = this.empList[j];
            this.empList[j] = this.emp;
          }
        }
      }
    }

    if(s == "dep"){
      for(let i =0; i<this.empList.length-1; i++){
        for(let j=i; j<this.empList.length; j++){
          if(this.empList[i].empDep > this.empList[j].empDep){
            this.emp = this.empList[i];
            this.empList[i] = this.empList[j];
            this.empList[j] = this.emp;
          }
        }
      }
    }
    if(s == "doj"){
      for(let i =0; i<this.empList.length-1; i++){
        for(let j=i; j<this.empList.length; j++){
          if(this.empList[i].empjoiningdate > this.empList[j].empjoiningdate){
            this.emp = this.empList[i];
            this.empList[i] = this.empList[j];
            this.empList[j] = this.emp;
          }
        }
      }
    }
  }
}
