import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import LabelComponent from './component/labelComponent';
import AddProjectComponent from './component/AddProject';
import uuid from 'uuid';
import $ from 'jquery';
import TodoComponent from './component/Todos';

class App extends Component {
  constructor(props){
    super(props);
    this.state = {
      projects: [],
      todos: []
    }
  }
  componentDidMount(){
    this.getTodos();
  }

  getTodos(){
    // $.get("https://jsonplaceholder.typicode.com/todos", function(data, status){
    //     console.log("Data: " + data + "\nStatus: " + status);
    // });

    
    $.ajax({
      url: 'https://jsonplaceholder.typicode.com/todos',
      dataType: 'jsonp',
      cache: false,
      type: 'GET',
      success: function (data) {
        this.setState({ todos: data }, function () {
          console.log(this.state);
        });
      }.bind(this),
      error: function (xhr, status, err) {
        console.log(err);
      }
    });
  
  }

  componentWillMount() {
    console.log("In componentWillMount....");
    this.setState({
      projects: [
        { id:uuid.v4(), title: 'Business Website', category: 'Web Design', project_manager: 'Pawan', details: [{ duration: "2 Year", budget: '$2000k' }, { duration: "4 Year", budget: '2000k' }] },
        { id:uuid.v4(), title: 'Social Website', category: 'Web Design and Mobile App', project_manager: 'Pawan', details: [{ duration: "2 Year", budget: '2000k' }] },
        { id:uuid.v4(), title: 'Ecommerce Site', category: 'Web Development', project_manager: 'Pawan', details: [{ duration: "2 Year", budget: '2000k' }] },
      ]
    });
  }

  handleAddProject(newProject){
    console.log('in App.js');
    console.log(newProject);

    let proj = this.state.projects;
    proj.push(newProject);
    this.setState({projects:proj});
  }

  handleDeleteProject(id){
    let projectList = this.state.projects;
    let index = projectList.findIndex(p=>p.id===id);
    projectList.splice(index, 1);
    this.setState({
      projects:projectList
    });
  }


  render() {
    return (
      
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Welcome to React</h1>
        </header>
        <div className="App-intro">
          <AddProjectComponent addProject={this.handleAddProject.bind(this)}/>
          <LabelComponent onDelete={this.handleDeleteProject.bind(this)} projects={this.state.projects}/>
          <TodoComponent todos={this.state.todos}/>
        </div>
      </div>
    );
  }
}

export default App;
