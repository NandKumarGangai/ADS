import React, { Component } from 'react';
import PropTypes from 'prop-types';

class TodoItemComponent extends Component{
    constructor(props){
        super(props);
    }
    render() {
        
        return (
		<div>
            <li className="Todo">
                <strong>{this.props.todo.title}</strong>
            </li>
        </div>
        )
    }
}
TodoItemComponent.propTypes = {
  todo: PropTypes.object
}
export default TodoItemComponent;