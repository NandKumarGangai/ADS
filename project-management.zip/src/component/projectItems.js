import React, { Component } from 'react';
import ProjectItemDetails from './ProjectItemDetails';
class ProjectItems extends Component{
    constructor(props){
        super(props);
    }
    deleteProject(id){
        console.log("Project deleted from project items....");
        this.props.onDelete(id);
    }
    render() {

       let projectItm = this.props.project.details.map(detail=>{
                    //console.log(detail);
                    return (<ProjectItemDetails key={this.props.project.title} detail={detail}/>);
                });        
        return (       
		
            <ul style={{ marginTop: 20 }}>
                <li>{this.props.project.id}</li>
                <li>{this.props.project.title}</li>
                <li>{this.props.project.category}</li>
                <li>{this.props.project.project_manager}</li>
                <li>Details:</li>
                {projectItm}
                <a href="#" onClick={this.deleteProject.bind(this, this.props.project.id)}>Delete</a>
            </ul>
        )
    }
}
export default ProjectItems;