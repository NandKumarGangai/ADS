import React, { Component } from 'react';
import uuid from 'uuid';
class AddProjectComponent extends Component{
    constructor(props){
        super(props);
        this.state={
            newProject:{}
        }
    }

    static defaultProps = { categories:['Web Design', 'Web Dev', 'Mobile Dev']}

    addMovie(e){
        e.preventDefault();
        if(this.refs.title.value===""){
            alert("Invalid Name");
        }else{
        console.log('Submitted '+this.refs.title.value);
        this.setState({
            newProject:{
                id:uuid.v4(),
                title:this.refs.title.value,
                category: this.refs.category.value, 
                project_manager: 'Pawan', 
                details: [{ duration: "2 Year", budget: '2000k' }]               
            }
        }, function(){ 
            // console.log(this.state)
            this.props.addProject(this.state.newProject);
            });
            
        } //else       
    } //addmovie

    render() {
        let categoryOptions = this.props.categories.map(category=>{
            return <option key={'category'} value={category}>{category}</option>
        });
        return (
		<div className="jumbotron bg-success text-light">
            <h2>Add Project</h2>
            <form onSubmit={this.addMovie.bind(this)}>
                <div>
                    <label>Title:</label><br />
                    <input type='text' ref='title' />
                </div>
                <div>
                    <label>Category:</label><br />
                    <select ref='category'>
                        {categoryOptions}
                    </select>
                </div>
                <div>
                    <input type="submit" value="Add Movie"/>
                </div>
            </form>
		</div>
        )
    }
}
export default AddProjectComponent;