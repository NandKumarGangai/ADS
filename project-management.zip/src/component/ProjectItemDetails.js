import React, { Component } from 'react';

class ProjectItemDetails extends Component{
    constructor(props){
        super(props);
    }
    render() {
        
        return (
		<ul>
	        <li>{this.props.detail.duration}</li>
            <li>{this.props.detail.budget}</li>
		</ul>
        )
    }
}
export default ProjectItemDetails;