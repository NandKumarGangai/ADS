import React, { Component } from 'react';
import PropTypes from 'prop-types';

import ProjectItems from './projectItems';
class LabelComponent extends Component{
    constructor(props){
        super(props);
    }

    deleteProject(id){
        console.log("Project deleted from project (labelComponent)....");
        this.props.onDelete(id);
    }
    render() {
        let projectItm;
        if(this.props.projects){
            projectItm = this.props.projects.map(project=>{console.log(project)
            return (<ProjectItems onDelete={this.deleteProject.bind(this)} key={project.title} project={project}/>);
            });
        }
        return (
		<div className="demo">
	            {/*<label className="label">In LabelComponent</label>*/}
                <br/>
                {/*{console.log(this.props.projects)}*/}
                <div className="col-md-3">
                  {projectItm}
                </div>

		</div>
        )
    }

    
}
LabelComponent.propTypes={
        projects: PropTypes.array,
        onDelete: PropTypes.func
    }
export default LabelComponent;