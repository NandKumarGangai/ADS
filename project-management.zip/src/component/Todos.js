import React, { Component } from 'react';
import TodoItemComponent from './TodoItem';
import PropTypes from 'prop-types';

class TodoComponent extends Component{
    constructor(props){
        super(props);
    }
    render() {
        let todoItems;
        if (this.props.todos) {
            todoItems = this.props.todos.map(todo => {
                //console.log(project);
                return (
                    <TodoItemComponent key={todo.title} todo={todo} />
                );
            }); 
        }
        return (
            <div className="Todos">
                <h3>Todo List</h3>
                {todoItems}
            </div>
        )
    }
}
TodoComponent.propTypes = {
  todos: PropTypes.array
}
export default TodoComponent;